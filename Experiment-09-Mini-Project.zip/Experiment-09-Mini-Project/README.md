# Time Series-Based Stock Price Forecasting with Linear Regression

**BDML Lab – Experiment 9 (Mini-Project)**

## Aim
To download historical Apple (AAPL) stock data, analyse it, and build a Linear Regression model that estimates a day's closing price from the closing prices of the previous days.

## Problem statement
Stock prices form a *time series* (values recorded in time order). Given the past closing prices, can a simple Linear Regression model estimate the next closing price, and how large are its errors on data it has never seen?

## Objectives
1. Download AAPL data with `yfinance` and save it as a CSV.
2. Describe the data (shape, columns, types, first rows, price statistics).
3. Plot closing price, trading volume and a simple moving average.
4. Create lag features, split the data **by time**, train Linear Regression.
5. Compare actual and predicted prices and measure MAE and RMSE.

## Software and hardware requirements
| | |
|---|---|
| OS | Windows 10/11 (also works on macOS/Linux) |
| Software | Python 3.9+ and VS Code (with the Python extension) |
| Internet | Needed for the first download; later runs can use the saved CSV |
| Hardware | Any normal laptop (2 GB free RAM; no GPU needed) |

## Libraries used
`pandas` (tables), `numpy` (maths), `yfinance` (download data), `matplotlib` (graphs), `scikit-learn` (Linear Regression and error metrics).

## Algorithm
1. Download `AAPL` for the last 5 years. If this fails, load the previously saved CSV.
2. Clean: flatten MultiIndex columns, keep Open/High/Low/Close/Volume, sort by date, drop missing rows, save to `data/AAPL_stock_data.csv`.
3. Print shape, column names, data types, first 5 rows and closing-price mean/median/min/max/std.
4. Save three graphs: closing price, volume, 50-day moving average.
5. Build features: for each day, `lag_1 … lag_5` = the closing prices of the 5 previous days. The target is that day's closing price.
6. Split chronologically: first 80 % of days → training, last 20 % → testing (no shuffling).
7. Fit `LinearRegression` on the training part.
8. Predict the test part; calculate MAE and RMSE.
9. Also calculate a **baseline** (predict "same as yesterday") so the model can be judged fairly.
10. Save the actual-vs-predicted graph and `outputs/results.txt`.

### The model in simple words
Linear Regression learns a weighted sum:

`predicted close = b0 + w1·(yesterday) + w2·(2 days ago) + … + w5·(5 days ago)`

Training finds the weights `w` that make the sum as close as possible to the real prices in the training period. The testing period is then used to see how well those weights work on unseen days.

## Step-by-step procedure
1. Install Python and VS Code, extract the project and open it in VS Code.
2. Create and activate a virtual environment, install the libraries.
3. Run `python main.py`.
4. Read the printed overview and results; open the PNG files in `outputs/`.

## Project structure
```
Experiment-09-Mini-Project/
├── main.py            # the whole program (download → analyse → model)
├── requirements.txt   # libraries to install
├── README.md
├── .gitignore
├── data/
│   └── .gitkeep       # AAPL_stock_data.csv is created here when you run
├── outputs/
│   └── .gitkeep       # graphs and results.txt are created here
└── tests/
    └── test_main.py   # offline unit tests (synthetic data)
```

## VS Code installation and execution commands (Windows)

**1. Download and extract** – Download `Experiment-09-Mini-Project.zip`, right-click → *Extract All…*, choose e.g. `C:\Users\<you>\Documents`.

**2. Open in VS Code** – Start VS Code → *File → Open Folder…* → select `Experiment-09-Mini-Project`. (Or in a terminal: `cd C:\Users\<you>\Documents\Experiment-09-Mini-Project` then `code .`)

**3. Open the terminal** – *Terminal → New Terminal* (PowerShell).

**4. Create and activate a virtual environment**
```powershell
python -m venv venv
venv\Scripts\Activate.ps1
```
If PowerShell says scripts are disabled, run this once and activate again:
```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```
(In Command Prompt use `venv\Scripts\activate.bat`.) You should see `(venv)` at the start of the prompt.

**5. Install the libraries**
```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

**6. Run the project**
```powershell
python main.py
```
Useful options:
```powershell
python main.py --period 10y     # more history
python main.py --offline        # use the saved CSV, no download
python main.py --show           # also open the graphs in windows
```

**7. Run the tests (optional)**
```powershell
python -m unittest discover -s tests -v
```

## Explanation of the generated graphs
| File | What it shows |
|---|---|
| `01_closing_price.png` | Closing price over time – the overall trend and big rises/falls. |
| `02_trading_volume.png` | Number of shares traded each day – high bars mean heavy trading activity. |
| `03_moving_average.png` | Closing price plus the 50-day simple moving average (average of the last 50 closes). It smooths daily noise, so the trend is easier to see. |
| `04_actual_vs_predicted.png` | In the test period, the real closing price (solid) against the model's prediction (dashed). The closer the lines, the smaller the error. |

## MAE and RMSE
- **MAE (Mean Absolute Error)** = average of |actual − predicted|. "On average the prediction is off by this many dollars." Easy to interpret.
- **RMSE (Root Mean Squared Error)** = square root of the average of (actual − predicted)². Large mistakes are punished more, so RMSE ≥ MAE. Also in dollars.
- Lower is better for both. A big gap between RMSE and MAE means a few days had large errors.

## Result
The actual numbers depend on the date you run the program and the data Yahoo Finance returns, so **no fixed result is written here**. After running, see the terminal output and `outputs/results.txt`, which contain:
- training and testing date ranges,
- MAE and RMSE of the Linear Regression model,
- MAE and RMSE of the "same as yesterday" baseline.

Write your own observed values in your lab record. Expect the model to follow the real price closely, because tomorrow's price is usually near today's, and expect it to be only about as good as the baseline. That is a normal and honest outcome for this simple method, not a bug.

## Limitations
- Stock prices depend on news, earnings, the economy and human behaviour; past closing prices alone cannot capture this.
- Linear Regression only draws a straight-line relationship; it cannot learn complex patterns.
- The model predicts one day using *real* previous prices; it is not a long-term forecast.
- Results change with the period and the market's behaviour in the test window.
- Prices are adjusted for splits and dividends (`auto_adjust=True`).
- This is an educational project, **not financial advice**, and it does not guarantee future prices.

## Viva questions and answers
1. **What is a time series?** Data recorded in time order, e.g. daily closing prices.
2. **Why not shuffle the data when splitting?** Shuffling would let the model train on future days and be tested on past days, which gives unrealistically good results. We split by time.
3. **What are lag features?** Earlier values used as inputs, e.g. `lag_1` is yesterday's close.
4. **Why do the first rows get dropped after creating lags?** The first 5 days do not have 5 previous days, so their lag values are missing.
5. **What is Linear Regression?** A model that fits a straight-line (weighted-sum) relationship between inputs and a number to predict.
6. **What is the training set and the test set?** Training data teaches the model; test data (unseen) checks it.
7. **Explain MAE and RMSE.** See the section above. MAE = average error; RMSE = like MAE but punishes big errors more.
8. **What is a moving average?** The average of the last N prices, recalculated each day; it smooths noise.
9. **What is the baseline and why use it?** "Tomorrow = today". If our model cannot beat it, it adds little value.
10. **What is MultiIndex and why handle it?** Newer yfinance returns two-level column names like `("Close","AAPL")`; we keep only the first level so `df["Close"]` works.
11. **What happens if the download fails?** The program prints a warning and uses the saved CSV; if there is none, it prints a clear error.
12. **Can this predict the real future price?** No. It only shows how well a simple model fits past data.
13. **Why was the market data adjusted?** Splits and dividends would otherwise create fake jumps in the price.
14. **How could you improve it?** More features (volume, moving averages), other models, and walk-forward testing – outside this experiment's scope.

## Upload to GitHub and push updates
1. Create an empty repository on github.com (no README), e.g. `Experiment-09-Mini-Project`.
2. In the VS Code terminal (inside the project folder):
```powershell
git init
git add .
git commit -m "Initial commit: Experiment 9 stock forecasting"
git branch -M main
git remote add origin https://github.com/<your-username>/Experiment-09-Mini-Project.git
git push -u origin main
```
3. Later updates:
```powershell
git add .
git commit -m "Describe what you changed"
git push
```
If Git asks who you are (first time only):
```powershell
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
```
Generated CSV/PNG/TXT files are ignored by `.gitignore`; only the code and folders are uploaded.

## Testing note
The unit tests in `tests/` use synthetic (randomly generated) prices and a fake `yfinance`, so they verify the program logic without internet. A real Yahoo Finance download must be checked by you on your own computer.
