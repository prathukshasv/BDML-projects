"""Tests for main.py.

IMPORTANT: these tests use SYNTHETIC prices (a random walk) and a fake
yfinance module, so they check the program's logic without internet.
They do NOT prove that a real Yahoo Finance download works.

Run:  python -m unittest discover -s tests -v
"""
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock

import matplotlib
matplotlib.use("Agg")
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import main  # noqa: E402


def fake_prices(n=400, multiindex=False):
    rng = np.random.default_rng(0)
    idx = pd.bdate_range("2022-01-03", periods=n)
    close = 100 + np.cumsum(rng.normal(0, 1, n))
    df = pd.DataFrame({"Open": close, "High": close + 1, "Low": close - 1,
                       "Close": close, "Volume": rng.integers(1_000_000, 5_000_000, n)}, index=idx)
    if multiindex:
        df.columns = pd.MultiIndex.from_product([df.columns, ["AAPL"]])
    return df


class TempDirCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.patches = [mock.patch.object(main, "DATA_DIR", root / "data"),
                        mock.patch.object(main, "OUTPUT_DIR", root / "outputs")]
        for p in self.patches:
            p.start()
        self.root = root

    def tearDown(self):
        for p in self.patches:
            p.stop()
        self.tmp.cleanup()


class TestCleaning(unittest.TestCase):
    def test_multiindex_columns_are_flattened(self):
        out = main.clean_dataframe(fake_prices(multiindex=True))
        self.assertEqual(list(out.columns), main.KEEP_COLUMNS)

    def test_missing_values_removed(self):
        df = fake_prices(50)
        df.iloc[3, 3] = np.nan
        self.assertEqual(len(main.clean_dataframe(df)), 49)

    def test_missing_column_raises(self):
        with self.assertRaises(main.DataError):
            main.clean_dataframe(fake_prices(50).drop(columns="Volume"))


class TestModel(unittest.TestCase):
    def test_lag_features_align(self):
        df = fake_prices(50)
        data = main.make_lag_features(df, 3)
        row = data.index[0]
        pos = df.index.get_loc(row)
        self.assertEqual(data.loc[row, "lag_1"], df["Close"].iloc[pos - 1])
        self.assertEqual(data.loc[row, "lag_3"], df["Close"].iloc[pos - 3])
        self.assertEqual(len(data), 47)

    def test_split_is_chronological_with_no_overlap(self):
        data = main.make_lag_features(fake_prices(200))
        train, test = main.chronological_split(data)
        self.assertLess(train.index.max(), test.index.min())
        self.assertEqual(len(train) + len(test), len(data))
        self.assertAlmostEqual(len(test) / len(data), 0.2, places=1)

    def test_too_little_data(self):
        with self.assertRaises(main.DataError):
            main.chronological_split(main.make_lag_features(fake_prices(20)))

    def test_metrics_known_values(self):
        mae, rmse = main.evaluate([1, 2, 3], [2, 2, 5])
        self.assertAlmostEqual(mae, 1.0)
        self.assertAlmostEqual(rmse, np.sqrt(5 / 3))

    def test_train_and_test_runs(self):
        res = main.train_and_test(fake_prices(300))
        self.assertEqual(len(res["predictions"]), len(res["test"]))
        self.assertGreater(res["mae"], 0)
        self.assertGreaterEqual(res["rmse"], res["mae"])


class TestPipeline(TempDirCase):
    def _fake_yf(self, df=None, error=None):
        mod = types.ModuleType("yfinance")
        def download(*a, **k):
            if error:
                raise error
            return df
        mod.download = download
        return mock.patch.dict(sys.modules, {"yfinance": mod})

    def test_download_saves_csv_and_run_creates_outputs(self):
        with self._fake_yf(fake_prices(400, multiindex=True)):
            main.run("AAPL", "5y")
        self.assertTrue(main.csv_path("AAPL").exists())
        for name in ["01_closing_price.png", "02_trading_volume.png", "03_moving_average.png",
                     "04_actual_vs_predicted.png", "results.txt"]:
            self.assertTrue((main.OUTPUT_DIR / name).exists(), name)

    def test_download_failure_falls_back_to_saved_csv(self):
        main.DATA_DIR.mkdir()
        main.clean_dataframe(fake_prices(100)).to_csv(main.csv_path("AAPL"))
        with self._fake_yf(error=RuntimeError("no internet")):
            df = main.get_data("AAPL")
        self.assertEqual(len(df), 100)

    def test_download_failure_without_csv_gives_clear_error(self):
        with self._fake_yf(error=RuntimeError("no internet")):
            with self.assertRaises(main.DataError) as ctx:
                main.get_data("AAPL")
        self.assertIn("No data available", str(ctx.exception))

    def test_empty_download_is_an_error(self):
        with self._fake_yf(df=pd.DataFrame()):
            with self.assertRaises(main.DataError):
                main.download_data()

    def test_main_returns_1_on_failure(self):
        with self._fake_yf(error=RuntimeError("x")):
            self.assertEqual(main.main([]), 1)


if __name__ == "__main__":
    unittest.main()
