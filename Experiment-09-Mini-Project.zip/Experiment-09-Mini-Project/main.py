"""
Time Series-Based Stock Price Forecasting with Linear Regression
BDML Lab - Experiment 9

What this program does (in order):
  1. Downloads historical AAPL data with yfinance and saves it as a CSV  (data/)
  2. Describes the data and draws 3 graphs                               (outputs/)
  3. Trains a Linear Regression model on lagged closing prices,
     tests it on the most recent part of the data, and draws a 4th graph (outputs/)

Run:   python main.py
Help:  python main.py --help

This is a learning exercise. It does NOT predict the future and is not
financial advice.
"""

import argparse
import sys
from pathlib import Path

import matplotlib
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "outputs"

TICKER = "AAPL"
PERIOD = "5y"          # how much history to download
SMA_WINDOW = 50        # days used for the simple moving average
N_LAGS = 5             # how many previous days' closing prices the model sees
TEST_FRACTION = 0.2    # last 20 % of the days are kept for testing
KEEP_COLUMNS = ["Open", "High", "Low", "Close", "Volume"]


class DataError(Exception):
    """Raised when no usable data can be obtained. The message is meant for the user."""


# --------------------------------------------------------------------------
# Step A - get the data
# --------------------------------------------------------------------------
def csv_path(ticker):
    return DATA_DIR / f"{ticker}_stock_data.csv"


def clean_dataframe(df):
    """Make the downloaded table simple: one level of column names, only the
    columns we need, a sorted date index, and no missing values."""
    df = df.copy()

    # Newer yfinance versions return MultiIndex columns such as ("Close", "AAPL").
    # We keep only the first level ("Close") so the columns are plain names.
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)

    missing = [c for c in KEEP_COLUMNS if c not in df.columns]
    if missing:
        raise DataError(f"The data is missing the columns: {missing}")

    df = df[KEEP_COLUMNS]
    df.index = pd.to_datetime(df.index)
    df.index.name = "Date"
    df = df[~df.index.duplicated(keep="first")].sort_index()
    for col in KEEP_COLUMNS:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna()   # rows with missing values are removed
    return df


def download_data(ticker=TICKER, period=PERIOD):
    """Download from Yahoo Finance and return a cleaned DataFrame."""
    try:
        import yfinance as yf
    except ImportError:
        raise DataError("The 'yfinance' library is not installed. Run: pip install -r requirements.txt")

    try:
        raw = yf.download(ticker, period=period, auto_adjust=True, progress=False)
    except Exception as exc:  # network errors, rate limits, etc.
        raise DataError(f"Download failed: {exc}")

    if raw is None or raw.empty:
        raise DataError("Download returned no data (no internet, wrong ticker, or Yahoo is busy).")
    return clean_dataframe(raw)


def load_saved_csv(ticker=TICKER):
    path = csv_path(ticker)
    if not path.exists():
        raise DataError(f"No saved file found at {path}.")
    df = pd.read_csv(path, index_col="Date", parse_dates=True)
    return clean_dataframe(df)


def get_data(ticker=TICKER, period=PERIOD, offline=False):
    """Download new data, or fall back to the previously saved CSV."""
    DATA_DIR.mkdir(exist_ok=True)
    if not offline:
        try:
            df = download_data(ticker, period)
            df.to_csv(csv_path(ticker))
            print(f"Downloaded {len(df)} rows. Saved to {csv_path(ticker)}")
            return df
        except DataError as err:
            print(f"[Warning] {err}")
            print("Trying the previously saved CSV instead...")
    try:
        df = load_saved_csv(ticker)
    except DataError as err:
        raise DataError(
            f"{err}\nNo data available. Connect to the internet and run again "
            "(the first successful run saves the CSV for later offline use)."
        )
    print(f"Loaded {len(df)} rows from the saved file {csv_path(ticker)}")
    return df


# --------------------------------------------------------------------------
# Step B - analyse the data
# --------------------------------------------------------------------------
def describe_data(df):
    print("\n=== Dataset overview ===")
    print("Shape (rows, columns):", df.shape)
    print("Column names:", list(df.columns))
    print("\nData types:")
    print(df.dtypes.to_string())
    print("\nFirst five rows:")
    print(df.head().to_string())


def closing_price_stats(df):
    close = df["Close"]
    stats = {
        "Mean": close.mean(),
        "Median": close.median(),
        "Minimum": close.min(),
        "Maximum": close.max(),
        "Standard deviation": close.std(),
    }
    print("\n=== Closing price statistics (USD) ===")
    for name, value in stats.items():
        print(f"{name:<20}: {value:10.2f}")
    return stats


def _save(fig, name, show):
    path = OUTPUT_DIR / name
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    if show:
        import matplotlib.pyplot as plt
        plt.show()
    import matplotlib.pyplot as plt
    plt.close(fig)
    print(f"Saved graph: {path}")
    return path


def plot_close(df, ticker, show=False):
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(df.index, df["Close"], color="tab:blue")
    ax.set(title=f"{ticker} closing price", xlabel="Date", ylabel="Price (USD)")
    ax.grid(alpha=0.3)
    return _save(fig, "01_closing_price.png", show)


def plot_volume(df, ticker, show=False):
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(df.index, df["Volume"], width=1.0, color="tab:gray")
    ax.set(title=f"{ticker} daily trading volume", xlabel="Date", ylabel="Shares traded")
    ax.grid(alpha=0.3)
    return _save(fig, "02_trading_volume.png", show)


def add_moving_average(df, window=SMA_WINDOW):
    """Simple moving average = the average of the last `window` closing prices."""
    return df["Close"].rolling(window=window).mean()


def plot_moving_average(df, ticker, window=SMA_WINDOW, show=False):
    import matplotlib.pyplot as plt
    sma = add_moving_average(df, window)
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(df.index, df["Close"], label="Close", color="tab:blue", alpha=0.6)
    ax.plot(df.index, sma, label=f"{window}-day moving average", color="tab:red")
    ax.set(title=f"{ticker} closing price with {window}-day moving average",
           xlabel="Date", ylabel="Price (USD)")
    ax.legend()
    ax.grid(alpha=0.3)
    return _save(fig, "03_moving_average.png", show)


# --------------------------------------------------------------------------
# Step C - Linear Regression
# --------------------------------------------------------------------------
def make_lag_features(df, n_lags=N_LAGS):
    """Build a table where each row holds the previous `n_lags` closing prices
    (the inputs, X) and the closing price of that day (the answer, y).

        lag_1 = yesterday's close, lag_2 = the day before, ...
    """
    data = pd.DataFrame(index=df.index)
    for k in range(1, n_lags + 1):
        data[f"lag_{k}"] = df["Close"].shift(k)
    data["target"] = df["Close"]
    return data.dropna()      # the first n_lags rows have no full history


def chronological_split(data, test_fraction=TEST_FRACTION):
    """Oldest rows -> training, newest rows -> testing. No shuffling,
    so the model is never trained on data from the future."""
    if len(data) < 30:
        raise DataError("Not enough rows to train and test a model (need at least 30).")
    split = int(len(data) * (1 - test_fraction))
    return data.iloc[:split], data.iloc[split:]


def evaluate(y_true, y_pred):
    mae = mean_absolute_error(y_true, y_pred)
    rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))
    return mae, rmse


def train_and_test(df, n_lags=N_LAGS, test_fraction=TEST_FRACTION):
    data = make_lag_features(df, n_lags)
    train, test = chronological_split(data, test_fraction)
    features = [c for c in data.columns if c != "target"]

    model = LinearRegression()
    model.fit(train[features], train["target"])
    predictions = pd.Series(model.predict(test[features]), index=test.index, name="Predicted")

    mae, rmse = evaluate(test["target"], predictions)
    # Baseline for comparison: "tomorrow's price = today's price"
    base_mae, base_rmse = evaluate(test["target"], test["lag_1"])

    return {
        "model": model, "features": features,
        "train": train, "test": test, "predictions": predictions,
        "mae": mae, "rmse": rmse,
        "baseline_mae": base_mae, "baseline_rmse": base_rmse,
    }


def plot_actual_vs_predicted(result, ticker, show=False):
    import matplotlib.pyplot as plt
    test = result["test"]
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(test.index, test["target"], label="Actual", color="tab:blue")
    ax.plot(test.index, result["predictions"], label="Predicted", color="tab:orange", linestyle="--")
    ax.set(title=f"{ticker}: actual vs predicted closing price (test period)",
           xlabel="Date", ylabel="Price (USD)")
    ax.legend()
    ax.grid(alpha=0.3)
    return _save(fig, "04_actual_vs_predicted.png", show)


def report_model(result, n_lags=N_LAGS):
    train, test = result["train"], result["test"]
    lines = [
        "=== Linear Regression results ===",
        f"Inputs (features)  : closing prices of the previous {n_lags} days",
        f"Training period    : {train.index[0].date()} to {train.index[-1].date()} ({len(train)} days)",
        f"Testing period     : {test.index[0].date()} to {test.index[-1].date()} ({len(test)} days)",
        f"MAE                : {result['mae']:.2f} USD",
        f"RMSE               : {result['rmse']:.2f} USD",
        f"Baseline MAE       : {result['baseline_mae']:.2f} USD  (just repeat yesterday's close)",
        f"Baseline RMSE      : {result['baseline_rmse']:.2f} USD",
        "Note: these numbers describe the past test period only. They do not",
        "guarantee anything about future prices.",
    ]
    text = "\n".join(lines)
    print("\n" + text)
    return text


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------
def parse_args(argv=None):
    p = argparse.ArgumentParser(description="AAPL stock price forecasting with Linear Regression")
    p.add_argument("--ticker", default=TICKER, help="stock symbol (default: AAPL)")
    p.add_argument("--period", default=PERIOD, help="history to download, e.g. 2y, 5y, 10y (default: 5y)")
    p.add_argument("--offline", action="store_true", help="skip the download and use the saved CSV")
    p.add_argument("--show", action="store_true", help="also open each graph in a window")
    return p.parse_args(argv)


def run(ticker=TICKER, period=PERIOD, offline=False, show=False):
    if not show:
        matplotlib.use("Agg")      # draw to files only, no window
    OUTPUT_DIR.mkdir(exist_ok=True)

    df = get_data(ticker, period, offline)
    describe_data(df)
    stats = closing_price_stats(df)

    print()
    plot_close(df, ticker, show)
    plot_volume(df, ticker, show)
    plot_moving_average(df, ticker, show=show)

    result = train_and_test(df)
    plot_actual_vs_predicted(result, ticker, show)
    summary = report_model(result)

    with open(OUTPUT_DIR / "results.txt", "w", encoding="utf-8") as f:
        f.write(f"Ticker: {ticker}\nRows: {len(df)}\n")
        f.write("Closing price statistics: " + ", ".join(f"{k}={v:.2f}" for k, v in stats.items()) + "\n\n")
        f.write(summary + "\n")
    print(f"\nDone. Graphs and results.txt are in {OUTPUT_DIR}")
    return df, result


def main(argv=None):
    args = parse_args(argv)
    try:
        run(args.ticker.upper(), args.period, args.offline, args.show)
    except DataError as err:
        print(f"\n[Error] {err}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
